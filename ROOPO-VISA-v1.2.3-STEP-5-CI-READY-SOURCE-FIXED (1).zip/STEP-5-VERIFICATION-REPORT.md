# Step 5 — CI-ready source and verification report

## Completed in this step
- Added `scripts/smoke-test.mjs` to launch the production Next.js server and check 18 public routes/resources, including the legacy Indian Medical URL redirect, Blog listing/category/tag routes, sitemap, robots file, and manifest.
- Added `npm run test:smoke`.
- Updated `.github/workflows/linux-production-build.yml` to run `npm ci`, static preflight, lint, TypeScript, unit/security tests, production build, and runtime smoke tests before packaging.
- The cPanel deployment ZIP is generated and uploaded as a GitHub Actions artifact only after every prior step passes.
- Updated deployment instructions to reflect the recovered hero assets and the new smoke tests.
- Confirmed package version and lockfile version are aligned at 1.2.3.
- Static preflight: 0 failures, 1 warning.
- JavaScript syntax checks and workflow YAML parsing passed.
- Confirmed there are no `.env`, `.env.local`, or `.env.production` files in the source package.

## Blocker: dependency installation
`npm ci --no-audit --no-fund` was attempted in this environment but could not finish because npm registry requests failed with `EAI_AGAIN` DNS errors. Consequently, ESLint, TypeScript, unit tests, `next build`, and runtime smoke tests have not been successfully executed here. No production deployment ZIP has been fabricated or claimed as built.

## Required next action in a network-enabled Linux CI runner
1. Put this source in a private GitHub repository.
2. Push to `main`/`master` or manually run Actions → `Roopo Visa Linux Production Build`.
3. If the workflow fails, fix the first failing step and rerun.
4. Only after a green workflow, download `ROOPO-VISA-v1.2.3-CPANEL-DEPLOY` from the workflow's Artifacts section and verify the accompanying SHA-256 file.

## Production safeguards
- CI uses a placeholder `APP_SECRET`; replace it with a unique random secret in cPanel.
- Configure real DB and SMTP values in cPanel environment settings; never commit or package them.
- Back up the database before applying the additive blog migration.
- Verify existing admin access before creating any new administrator.
- Privacy Policy and Terms of Use still require owner/legal review.
