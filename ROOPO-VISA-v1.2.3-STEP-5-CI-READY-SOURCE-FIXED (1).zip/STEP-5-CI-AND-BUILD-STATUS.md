# Step 5 — Linux build and runtime verification

## What is prepared
- GitHub Actions workflow installs the lockfile dependencies on Linux.
- Runs static preflight, ESLint, TypeScript, unit/security tests, and a production build.
- Starts the built Next.js production server and checks the 12 primary public routes, Blog listing/category/tag routes, sitemap, robots file, manifest, and legacy Indian Medical URL redirect.
- Creates the cPanel ZIP only if all previous steps pass, then checks ZIP integrity and writes a SHA-256 checksum.
- CI uses a build-only placeholder secret. Production credentials must be configured in cPanel and must never be committed or bundled.

## Current verification status
- Static preflight: passed locally (0 failures, 1 warning).
- npm ci: attempted in the current environment but could not finish because npm registry DNS requests failed with EAI_AGAIN.
- Lint, TypeScript, unit tests, production build, runtime smoke tests: not yet executed successfully.
- Deployment artifact: not generated here. GitHub Actions will generate it only after all checks pass.

## How to run
1. Upload/extract this source into a private GitHub repository (or replace the existing project source after backing it up).
2. Commit and push to `main` or `master`.
3. Open GitHub repository → Actions → `Roopo Visa Linux Production Build` → Run workflow (or wait for push-triggered run).
4. If a step fails, open that step's log and fix the first failure before proceeding.
5. When the workflow succeeds, download artifact `ROOPO-VISA-v1.2.3-CPANEL-DEPLOY`; verify its `.sha256` file before deployment.

A successful static preflight alone is not proof of a successful production build or live deployment.
