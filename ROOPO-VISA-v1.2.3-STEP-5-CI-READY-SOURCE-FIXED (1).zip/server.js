// Phusion Passenger / cPanel "Application startup file". Runs the production Next.js server.
// Build first (`npm run build`). Do not use `next dev` in production.
const { createServer } = require('node:http');
const next = require('next');
const app = next({ dev: false, hostname: '0.0.0.0', port: Number(process.env.PORT || 3000) });
const handle = app.getRequestHandler();
app.prepare().then(() => {
  createServer((req, res) => handle(req, res)).listen(process.env.PORT || 3000, () => console.log('Roopo Visa ready'));
}).catch((e) => { console.error('Startup failed:', e.message); process.exit(1); });
