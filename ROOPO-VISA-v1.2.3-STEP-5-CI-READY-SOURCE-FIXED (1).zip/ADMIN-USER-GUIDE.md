# Roopo Visa Admin — User Guide

Sign in at `/admin/login`. Sessions last 8 hours; use **Sign out** on shared computers. This is a **single-owner** design: one administrator account, no roles (documented limitation — add roles before giving staff separate access).

- **Dashboard** — live counts from the database: enquiries by status, last 7 days, enquiries whose email notification failed, content/FAQ/email readiness.
- **Enquiries** — every valid website submission is stored first. Search (name/email/phone/message), filter by status and email-delivery state. Open one to change status (New → In Progress → Replied → Closed), add internal notes, or permanently delete (tick the confirmation box). Replying is done from your own email/phone (use the email link); mark it *Replied* afterwards.
- **Content** — edit homepage hero/sections, the six service pages, per-page SEO (title, description, canonical, Open Graph), and **Site settings** (phone numbers, address, optional public email, social links, private notification recipient, base URL). Saving publishes immediately. *Reset to defaults* restores the original text for that section. If a field is rejected, you are returned to the form and the fields to fix are named (your last typed text is not kept — keep long edits in a note first).
- **FAQ** — first visit shows the built-in questions; click *Import* to edit them. Add, edit, reorder (lower number first), hide (unpublish) or delete.
- **Settings** — SMTP status (secrets never displayed), send a test email, edit profile, change password (12+ chars, three character types; other sessions are signed out).

Not editable here: About body text and Privacy/Terms body text (remain in source; Privacy/Terms are **drafts pending owner/legal confirmation**).
Do not ask visitors to send passports or sensitive documents through the enquiry form.
