// Applies migrations/*.sql in filename order, once each. Usage: npm run db:migrate
import fs from 'node:fs';
import path from 'node:path';
import { connect } from './lib/db.mjs';

const dir = path.join(process.cwd(), 'migrations');
const files = fs.readdirSync(dir).filter((f) => /^\d+_.+\.sql$/.test(f)).sort();
const conn = await connect();
try {
  await conn.query('CREATE TABLE IF NOT EXISTS schema_migrations (version VARCHAR(100) NOT NULL PRIMARY KEY, applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
  const [rows] = await conn.query('SELECT version FROM schema_migrations');
  const done = new Set(rows.map((r) => r.version));
  let applied = 0;
  for (const f of files) {
    if (done.has(f)) { console.log(`skip   ${f}`); continue; }
    // Split on semicolons at statement ends; migrations must not contain procedural blocks.
    const statements = fs.readFileSync(path.join(dir, f), 'utf8').replace(/^\s*--.*$/gm, '').split(/;\s*(?:\n|$)/).map((s) => s.trim()).filter(Boolean);
    for (const s of statements) await conn.query(s);
    await conn.query('INSERT INTO schema_migrations (version) VALUES (?)', [f]);
    console.log(`apply  ${f}`); applied += 1;
  }
  console.log(`Done. ${applied} migration(s) applied, ${files.length - applied} already present.`);
} catch (e) {
  console.error('Migration failed:', e.code || '', e.message);
  process.exitCode = 1;
} finally { await conn.end(); }
