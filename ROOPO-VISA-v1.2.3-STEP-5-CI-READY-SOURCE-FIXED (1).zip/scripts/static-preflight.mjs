import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const appRoot = path.join(root, 'src', 'app');
const expectedRoutes = [
  '/', '/about', '/contact', '/faq', '/gvcw-appointment-support',
  '/indian-medical-travel-support', '/ivac-appointment-services',
  '/korean-visa-processing', '/privacy-policy', '/terms-of-use', '/blog',
  '/vfs-global-appointment-services', '/visa-processing-services',
];
const failures = [];
const warnings = [];
const ok = (message) => console.log(`PASS  ${message}`);
const fail = (message) => { failures.push(message); console.error(`FAIL  ${message}`); };
const warn = (message) => { warnings.push(message); console.warn(`WARN  ${message}`); };

function walk(dir) {
  const found = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) found.push(...walk(full));
    else found.push(full);
  }
  return found;
}

const pageFiles = walk(appRoot).filter((file) => path.basename(file) === 'page.tsx');
const actualRoutes = new Set(pageFiles.map((file) => {
  const rel = path.relative(appRoot, path.dirname(file)).split(path.sep).filter((seg) => !/^\(.+\)$/.test(seg)).join('/'); // route groups like (site) are not URL segments
  return rel === '.' ? '/' : `/${rel}`;
}));
for (const route of expectedRoutes) {
  if (!actualRoutes.has(route)) fail(`Missing required route: ${route}`);
  else ok(`Route exists: ${route}`);
}
for (const route of actualRoutes) if (!expectedRoutes.includes(route) && !route.startsWith('/admin') && !route.includes('[')) warn(`Additional route not in launch map: ${route}`);

const appRouteSet = new Set(actualRoutes);
const sourceFilesForLinks = walk(path.join(root, 'src')).filter((file) => /\.(tsx?|jsx?)$/.test(file));
const missingLinks = new Set();
for (const file of sourceFilesForLinks) {
  const content = fs.readFileSync(file, 'utf8');
  const pattern = /href\s*=\s*\{?\s*['"](\/[^'"`}\s]*)/g;
  for (const match of content.matchAll(pattern)) {
    const target = match[1].split('?')[0].split('#')[0];
    if (target.startsWith('/api/') || target.startsWith('/#') || target.includes('.')) continue;
    if (!appRouteSet.has(target)) missingLinks.add(`${path.relative(root, file)} -> ${target}`);
  }
}
if (missingLinks.size) for (const item of missingLinks) fail(`Internal link has no page route: ${item}`);
else ok('Static internal page links resolve to existing routes.');

// Dynamic blog routes are part of the public launch surface, but cannot be represented by the static route set above.
for (const [route, file] of [
  ['/blog/[slug]', 'src/app/(site)/blog/[slug]/page.tsx'],
  ['/blog/category/[category]', 'src/app/(site)/blog/category/[category]/page.tsx'],
  ['/blog/tag/[tag]', 'src/app/(site)/blog/tag/[tag]/page.tsx'],
]) {
  const full = path.join(root, file);
  if (!fs.existsSync(full)) fail(`Missing dynamic blog route: ${route}`);
  else if (fs.readFileSync(full, 'utf8').includes('generateMetadata')) ok(`Dynamic blog route and metadata configured: ${route}`);
  else fail(`Dynamic blog route is missing metadata: ${route}`);
}
const blogArticleSource = fs.readFileSync(path.join(root, 'src', 'app', '(site)', 'blog', '[slug]', 'page.tsx'), 'utf8');
if (blogArticleSource.includes("replace(/</g, '\\\\u003c')")) ok('Blog Article JSON-LD escapes < to prevent script-tag injection.');
else fail('Blog Article JSON-LD must escape < before embedding user-managed fields in a script tag.');

const metadataFile = path.join(root, 'src', 'lib', 'metadata.ts');
const metadataSource = fs.readFileSync(metadataFile, 'utf8');
if (/alternates:\s*\{\s*canonical:\s*['"]\//.test(metadataSource)) {
  fail('Root metadata defines a fixed canonical URL that may leak to all child routes.');
} else ok('Root metadata does not force the homepage canonical onto child routes.');
const fileByRoute = new Map(pageFiles.map((file) => {
  const rel = path.relative(appRoot, path.dirname(file)).split(path.sep).filter((seg) => !/^\(.+\)$/.test(seg)).join('/');
  return [rel === '' ? '/' : `/${rel}`, file];
}));
for (const route of expectedRoutes) {
  const file = fileByRoute.get(route);
  if (!file) continue;
  const source = fs.readFileSync(file, 'utf8');
  if (route.includes('[')) { if (source.includes('generateMetadata')) ok(`Dynamic route metadata configured: ${route}`); else fail(`Missing dynamic route metadata: ${route}`); continue; }
  if (route === '/indian-medical-travel-support') {
    if (source.includes("redirect('/ivac-appointment-services#indian-medical-guidance')")) ok('Legacy Indian medical URL redirects to the IVAC guidance anchor.');
    else fail('Legacy Indian medical URL must redirect to the IVAC guidance anchor.');
    continue;
  }
  if (source.includes(`pageMetadata('${route}'`)) ok(`Route-specific canonical metadata (pageMetadata) configured: ${route}`);
  else fail(`Missing route-specific pageMetadata/canonical: ${route}`);
}

const allSourceFiles = walk(path.join(root, 'src')).filter((file) => /\.(tsx?|jsx?)$/.test(file));
const sourceText = allSourceFiles.map((file) => fs.readFileSync(file, 'utf8')).join('\n');
for (const label of ['IVAC Appointment Services', 'VFS Global Appointment Services', 'Korean Visa Processing']) {
  if (sourceText.includes(label)) ok(`Priority service present: ${label}`);
  else fail(`Priority service missing: ${label}`);
}
for (const category of ['Korean tourist visa', 'Korean scholarship student visa', 'Korean business visa']) {
  if (sourceText.toLowerCase().includes(category.toLowerCase())) ok(`Korean category present: ${category}`);
  else fail(`Korean category missing: ${category}`);
}


const serviceMedia = [
  ['public/media/service-ivac.webp', 'public/media/service-ivac.gif'],
  ['public/media/service-vfs.webp', 'public/media/service-vfs.gif'],
  ['public/media/service-korea.webp', 'public/media/service-korea.gif'],
];
for (const [fallback, motion] of serviceMedia) {
  if (fs.existsSync(path.join(root, fallback)) && fs.existsSync(path.join(root, motion))) {
    ok(`Service media has static fallback and motion variant: ${fallback}`);
  } else fail(`Missing service media pair: ${fallback} + ${motion}`);
}
const homeSource = fs.readFileSync(path.join(appRoot, '(site)', 'page.tsx'), 'utf8');
if (homeSource.includes('listBlogPosts') && homeSource.includes('latest-guidance')) ok('Homepage includes a latest blog guidance preview.');
else fail('Homepage must include the latest blog guidance preview.');
const cardComponent = fs.readFileSync(path.join(root, 'src/components/ui/ServiceCard.tsx'), 'utf8');
if (cardComponent.includes('prefers-reduced-motion: no-preference') && cardComponent.includes('type="image/gif"')) ok('Animated service cards respect reduced-motion preference with static image fallback.');
else fail('Animated service cards must include a reduced-motion-safe static fallback.');

const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
for (const script of ['build', 'start', 'lint', 'typecheck']) {
  if (pkg.scripts?.[script]) ok(`Package script exists: ${script}`);
  else fail(`Package script missing: ${script}`);
}
if (!pkg.scripts['preflight:static']) warn('Add preflight:static script to package.json after validating this script.');

const apiFile = path.join(appRoot, 'api', 'contact', 'route.ts');
if (fs.existsSync(apiFile)) {
  const api = fs.readFileSync(apiFile, 'utf8');
  const saveAt = api.indexOf('createEnquiry('), mailAt = api.indexOf('sendEnquiryEmail(');
  if (saveAt > -1 && mailAt > saveAt) ok('Contact endpoint persists the enquiry BEFORE attempting email.');
  else fail('Contact endpoint must call createEnquiry before sendEnquiryEmail.');
  if (api.includes('status: 503') || api.includes(', 503)')) ok('Contact endpoint fails truthfully (503) if the enquiry cannot be saved.');
  else fail('Contact endpoint has no truthful failure path when the database is unavailable.');
} else fail('Contact API route missing.');

// Admin: every page must call requireAdmin(); every exported server action must call requireAdminAction/requireAdmin (login/logout excepted).
const adminRoot = path.join(appRoot, 'admin');
if (fs.existsSync(adminRoot)) {
  for (const file of walk(adminRoot).filter((f) => /page\.tsx$/.test(f))) {
    const rel = path.relative(root, file);
    const src = fs.readFileSync(file, 'utf8');
    if (rel.endsWith(path.join('login', 'page.tsx'))) { ok(`Admin login page (public by design): ${rel}`); continue; }
    if (/requireAdmin\(/.test(src)) ok(`Admin page enforces auth: ${rel}`); else fail(`Admin page missing requireAdmin(): ${rel}`);
  }
  const actionsFile = path.join(adminRoot, 'actions.ts');
  if (fs.existsSync(actionsFile)) {
    const src = fs.readFileSync(actionsFile, 'utf8');
    const parts = src.split(/export async function /).slice(1);
    for (const part of parts) {
      const name = part.slice(0, part.indexOf('('));
      if (['loginAction', 'logoutAction'].includes(name)) { ok(`Action ${name}: intentionally unauthenticated/self-contained`); continue; }
      const body = part.slice(0, 900);
      if (/requireAdminAction\(/.test(body)) ok(`Server action ${name} verifies session + CSRF.`); else fail(`Server action ${name} lacks requireAdminAction().`);
    }
  } else fail('admin/actions.ts missing.');
} else warn('No admin area present.');

if (/DEFAULT_PASSWORD|admin123|password123/i.test(sourceText)) fail('Possible hard-coded credential found in source.'); else ok('No obvious hard-coded credentials in source.');

const envExample = path.join(root, '.env.example');
if (fs.existsSync(envExample) && /REPLACE_WITH_|YOUR_CPANEL_|SMTP_PASSWORD=/i.test(fs.readFileSync(envExample, 'utf8')) && !/SMTP_PASSWORD=(?!\s*$)(?!REPLACE_WITH_|YOUR_)[^\s#]{8,}/i.test(fs.readFileSync(envExample, 'utf8'))) {
  ok('Environment example uses placeholders, not real credentials.');
} else warn('Review .env.example for accidental real secrets.');

if (sourceText.includes('Aitezaz Sikandar') || sourceText.includes('Portfolio-main') || sourceText.includes('aitezazdev')) {
  fail('Original portfolio identity appears in app source.');
} else ok('No known original Portfolio author identity in application source.');

for (const route of ['/privacy-policy', '/terms-of-use']) {
  const content = fs.readFileSync(fileByRoute.get(route), 'utf8');
  if (content.includes('DRAFT — pending')) ok(`${route} is visibly marked as a draft pending owner/legal confirmation.`);
  else fail(`${route} is not marked as a draft.`);
}
warn('This is a static preflight only. It does not replace npm install, lint, TypeScript, production build, browser testing, SMTP delivery, or hosting verification.');
console.log(`\nSummary: ${failures.length} failure(s), ${warnings.length} warning(s).`);
if (failures.length) process.exitCode = 1;
