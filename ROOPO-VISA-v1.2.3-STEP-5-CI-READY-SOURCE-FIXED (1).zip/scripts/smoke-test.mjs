import { spawn } from 'node:child_process';
import { setTimeout as delay } from 'node:timers/promises';

const port = Number(process.env.SMOKE_PORT || 3187);
const base = `http://127.0.0.1:${port}`;
const secret = 'ci-only-placeholder-secret-not-for-production-000000000000';
const child = spawn(process.execPath, ['node_modules/next/dist/bin/next', 'start', '-p', String(port)], {
  cwd: process.cwd(),
  env: { ...process.env, NODE_ENV: 'production', PORT: String(port), APP_SECRET: secret },
  stdio: ['ignore', 'pipe', 'pipe'],
});
let logs = '';
child.stdout.on('data', (chunk) => { logs += chunk.toString(); });
child.stderr.on('data', (chunk) => { logs += chunk.toString(); });

const routes = [
  '/', '/about', '/ivac-appointment-services', '/vfs-global-appointment-services',
  '/gvcw-appointment-support', '/korean-visa-processing', '/visa-processing-services',
  '/blog', '/blog/category/smoke-test', '/blog/tag/smoke-test', '/faq', '/contact',
  '/privacy-policy', '/terms-of-use', '/sitemap.xml', '/robots.txt', '/manifest.webmanifest',
  '/indian-medical-travel-support',
];

async function waitForServer() {
  for (let i = 0; i < 40; i += 1) {
    if (child.exitCode !== null) throw new Error(`Next server exited early.\n${logs}`);
    try {
      const response = await fetch(base, { signal: AbortSignal.timeout(2000) });
      if (response.status < 500) return;
    } catch { /* server is still starting */ }
    await delay(750);
  }
  throw new Error(`Next server did not become ready.\n${logs}`);
}

let failures = 0;
try {
  await waitForServer();
  for (const route of routes) {
    try {
      const response = await fetch(`${base}${route}`, { redirect: 'follow', signal: AbortSignal.timeout(15000) });
      const body = await response.text();
      if (response.status !== 200) throw new Error(`HTTP ${response.status}`);
      if (!body || body.length < 100) throw new Error('Response body is unexpectedly short');
      console.log(`PASS ${route} -> HTTP ${response.status}`);
    } catch (error) {
      failures += 1;
      console.error(`FAIL ${route}: ${error instanceof Error ? error.message : String(error)}`);
    }
  }
} finally {
  child.kill('SIGTERM');
  await Promise.race([new Promise((resolve) => child.once('exit', resolve)), delay(3000)]);
  if (child.exitCode === null) child.kill('SIGKILL');
}

if (failures) {
  console.error(`\nSmoke test failed: ${failures} route(s).`);
  console.error(logs.slice(-12000));
  process.exitCode = 1;
} else {
  console.log(`\nSmoke test passed: ${routes.length} route/resource checks.`);
}
