// One-time first-admin bootstrap (single-owner design). No default credentials exist.
// Usage:  ADMIN_EMAIL=you@domain ADMIN_NAME="Owner" ADMIN_PASSWORD='long-unique-pass' npm run admin:create
//         add ADMIN_RESET=true to set a new password for an existing admin (recovery).
// Remove ADMIN_PASSWORD from your shell history / environment afterwards.
import { connect } from './lib/db.mjs';
import { hashPassword, policyError } from './lib/password.mjs';

const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const name = (process.env.ADMIN_NAME || 'Owner').trim().slice(0, 100);
const password = process.env.ADMIN_PASSWORD || '';
const reset = process.env.ADMIN_RESET === 'true';
if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || email.length > 254) { console.error('Set ADMIN_EMAIL to a valid email address.'); process.exit(2); }
const problem = policyError(password, email);
if (problem) { console.error(`ADMIN_PASSWORD rejected: ${problem}`); process.exit(2); }

const conn = await connect();
try {
  const [rows] = await conn.query('SELECT id, email FROM admin_users');
  const hash = await hashPassword(password);
  if (rows.length && !reset) { console.error('An admin already exists. Bootstrap is one-time. Use ADMIN_RESET=true to reset that admin\'s password.'); process.exitCode = 3; }
  else if (rows.length && reset) {
    const target = rows.find((r) => r.email === email);
    if (!target) { console.error('ADMIN_RESET requires ADMIN_EMAIL to match the existing admin.'); process.exitCode = 3; }
    else {
      await conn.query('UPDATE admin_users SET password_hash = ? WHERE id = ?', [hash, target.id]);
      await conn.query('DELETE FROM admin_sessions WHERE user_id = ?', [target.id]);
      await conn.query("INSERT INTO audit_log (admin_id, action, detail) VALUES (?, 'password_reset_cli', 'via admin:create')", [target.id]);
      console.log('Password reset; all sessions revoked.');
    }
  } else {
    const [res] = await conn.query('INSERT INTO admin_users (email, display_name, password_hash) VALUES (?, ?, ?)', [email, name, hash]);
    await conn.query("INSERT INTO audit_log (admin_id, action, detail) VALUES (?, 'admin_created', 'via admin:create')", [res.insertId]);
    console.log(`Admin created: ${email}`);
  }
} catch (e) { console.error('Failed:', e.code || '', e.message); process.exitCode = 1; }
finally { await conn.end(); }
