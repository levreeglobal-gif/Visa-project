# Step 3 — Motion assets and verification status

## Completed
- Added animated GIFs for the three priority service cards: IVAC, VFS Global, and Korean visa.
- Added static WebP fallbacks for reduced-motion preferences.
- Updated the shared service card component and service configuration to use the image assets.
- Added subtle hover movement and disabled that motion for reduced-motion users.
- Added a homepage latest-blog preview using published posts, with a useful empty state when the blog has no published content.
- Added static-preflight checks for all six media files, the reduced-motion fallback, and the homepage blog preview.
- Static preflight passes with zero failures and one existing warning about the limits of static checks.

## Asset sizes
- IVAC GIF: approximately 0.38 MB; WebP fallback: approximately 0.013 MB.
- VFS GIF: approximately 0.46 MB; WebP fallback: approximately 0.016 MB.
- Korean visa GIF: approximately 0.43 MB; WebP fallback: approximately 0.015 MB.
- Total GIF payload: approximately 1.2 MB for all three cards.

## Not yet verified
- `npm ci` did not finish within the available execution window; dependency installation appears blocked or stalled. It was stopped rather than left running.
- ESLint, TypeScript, unit tests, full Next.js production build, browser QA, and cPanel runtime are therefore not claimed as passed.
- The locked hero video and poster files are still absent from the source archive; hero media needs a separate verified asset before visual parity can be considered complete.
- The generated card images are visual assets and must be reviewed against the approved reference before final production launch.

This is a source update, not a production deployment package.
