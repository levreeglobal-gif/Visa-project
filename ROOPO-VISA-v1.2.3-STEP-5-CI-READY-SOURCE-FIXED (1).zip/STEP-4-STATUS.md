# Step 4 Status — Release Candidate

- [x] Restore original hero video and poster assets from the earlier v1.2.3 final-source archive.
- [x] Preserve service GIF motion and WebP fallbacks.
- [x] Run static preflight: 0 failures, 1 warning.
- [x] Validate source ZIP structure and compute SHA-256.
- [ ] `npm ci` — blocked by npm registry DNS failures (`EAI_AGAIN`); required packages are not fully cached offline.
- [ ] Lint, TypeScript, unit tests, production build.
- [ ] Browser and live runtime verification.
- [ ] Produce verified cPanel deployment ZIP.

**Do not deploy this source ZIP over the live site.** It is not yet a verified production build.
