# Roopo Visa v1.2.3 — Step 3 Full-Site Audit

Audit basis: the uploaded `ROOPO-VISA-v1.2.3-STEP-3-MOTION-SOURCE.zip` source tree. This is a source/static audit, not a live-browser or production-runtime certification.

## Scope checked

- All public page route files and route-specific metadata.
- Shared header/footer/layout and global stylesheet impact.
- Homepage sections, three priority service cards, GIF/WebP media pairs and reduced-motion behavior.
- Indian Medical Visa legacy route and IVAC guidance anchor.
- Blog listing, article, category and tag routes; homepage latest-post preview; admin blog action protections.
- Sitemap/robots files, SEO metadata and Article structured data.
- Admin route authentication markers, contact API persistence/error behavior, static preflight and existing test availability.

## Route impact matrix

| Area | Source audit result | Status |
|---|---|---|
| Homepage `/` | Locked hero structure, three priority cards, medical and Korean student-finance subheroes, process, support sections, blog preview and FAQ preview are present | Source present; browser layout unverified |
| `/about` | Page file and route metadata present | Pass (static) |
| `/ivac-appointment-services` | Service page and Indian medical guidance article anchor present | Pass (static) |
| `/vfs-global-appointment-services` | Page file and route metadata present | Pass (static) |
| `/korean-visa-processing` | Page file and route metadata present | Pass (static) |
| `/gvcw-appointment-support` | Page file and route metadata present | Pass (static) |
| `/visa-processing-services` | Page file and route metadata present | Pass (static) |
| `/faq` | Page file and route metadata present | Pass (static) |
| `/contact` | Page file and contact API present; API statically checks persistence before email and 503 path | Pass (static), delivery untested |
| `/privacy-policy`, `/terms-of-use` | Pages exist but are marked draft pending owner/legal confirmation | Owner review required |
| `/blog` | Listing, SEO metadata and published-post query present | Pass (static), DB/runtime untested |
| `/blog/[slug]` | Article page, metadata, Open Graph/Twitter metadata and Article JSON-LD present | Pass after security fix; runtime untested |
| `/blog/category/[category]`, `/blog/tag/[tag]` | Dynamic taxonomy pages and metadata present | Pass (static), runtime untested |
| `/indian-medical-travel-support` | Redirects to `/ivac-appointment-services#indian-medical-guidance` | Pass (static) |
| `/admin/*` | Admin page files include auth checks; server actions include session/CSRF checks per static preflight | Pass (static), security/runtime test pending |

## Step 3 changes inspected

- Three animated GIFs exist: `service-ivac.gif`, `service-vfs.gif`, `service-korea.gif` (360×180; multiple frames verified).
- Each GIF has a WebP fallback; combined GIF payload is approximately 1.2 MB.
- Service card markup uses GIF only for `prefers-reduced-motion: no-preference`; static WebP remains fallback.
- Homepage latest blog preview shows up to three published posts and has an empty state.
- Shared stylesheet changes affect shared page elements site-wide; the GIF card change is limited to the three homepage priority cards, rather than being forced onto unrelated service pages.

## Issue found and fixed during audit

- **Blog Article JSON-LD escaping:** the source used a JavaScript string that evaluated to `<`, so it did not escape a less-than sign before placing editor-controlled article fields inside a script element. Updated it to emit the literal `\\u003c` escape sequence. Static preflight now explicitly checks this condition.

## Blockers / outstanding verification

1. **Hero media is missing:** `public/media/roopo-hero.mp4` and `public/media/roopo-hero-poster.jpg` are referenced by the homepage but absent from the ZIP. The site may render without the intended cinematic background; locked visual parity is not met until suitable assets are supplied and checked.
2. **No full build/test/browser verification:** `node_modules/.bin/tsx` is absent, so `npm test` could not run. Dependency installation did not complete in the previous build attempt. ESLint, TypeScript, full Next.js build, browser/mobile QA, database migration, SMTP delivery and cPanel runtime are not certified.
3. **Legal review:** privacy policy and terms pages are explicitly draft content; owner/legal review is required before launch.

## Static check result

`node scripts/static-preflight.mjs`: **0 failures, 1 warning**. The remaining warning states that static preflight does not replace dependency installation, lint, typecheck, production build, browser testing, SMTP delivery or hosting verification.

## Verdict

The source-level changes from Step 3 are localized as intended: shared CSS/layout affects all public pages, while GIF motion and the new blog preview are homepage-specific. No missing required public page was detected by static preflight. This package is **audited source, not a production-ready deployment ZIP** until hero media and runtime verification are complete.
