-- Blog and editorial SEO. Safe additive migration; existing records are untouched.
CREATE TABLE IF NOT EXISTS blog_posts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(180) NOT NULL,
  title VARCHAR(180) NOT NULL,
  excerpt VARCHAR(500) NOT NULL DEFAULT '',
  body LONGTEXT NOT NULL,
  category VARCHAR(100) NOT NULL DEFAULT 'Visa guidance',
  tags_json TEXT NOT NULL,
  author_name VARCHAR(100) NOT NULL DEFAULT 'Roopo Visa Editorial Team',
  seo_title VARCHAR(70) NOT NULL DEFAULT '',
  seo_description VARCHAR(200) NOT NULL DEFAULT '',
  og_image VARCHAR(500) NOT NULL DEFAULT '',
  published TINYINT(1) NOT NULL DEFAULT 0,
  published_at DATETIME NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_blog_slug (slug),
  KEY ix_blog_public (published, published_at),
  KEY ix_blog_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
