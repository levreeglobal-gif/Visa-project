# Roopo Visa v1.2.3 — cPanel Deployment Guide

**Current status:** merged source and static preflight are ready; production deployment is not yet verified. The approved hero video/poster and service GIF/WebP media are now included in this source. The Linux CI build must pass before the deployment artifact is treated as ready.

## 1. Build a deployment artifact (recommended)
1. Put this source in a private GitHub repository, preserving `.github/workflows/linux-production-build.yml`.
2. Push to `main`/`master` or run **Actions → Roopo Visa Linux Production Build → Run workflow**.
3. Wait for `npm ci`, static preflight, lint, typecheck, unit/security tests, `next build`, and production route smoke tests all to pass.
4. Download the `ROOPO-VISA-v1.2.3-CPANEL-DEPLOY` artifact only from a successful run. Do not upload the source ZIP itself as the live app package.

## 2. cPanel requirements
- Setup Node.js App / Passenger with Node.js 20 or 22 (Node 22 recommended).
- MySQL/MariaDB database and user with required privileges.
- HTTPS enabled for `visa.roopo.org`.
- A long-running Node.js app with application root outside the public web directory and startup file `server.js`.
- Enough RAM/process limit for Node/Next.js. If cPanel build runs out of memory, build on Linux CI and upload the verified deployment artifact instead.

## 3. Configure environment variables
Use `.env.example` as the key list, but enter real values in the cPanel Node.js App environment settings. Set `APP_SECRET` to a unique random string of at least 32 characters. Configure either `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`, or `DATABASE_URL`. Set SMTP values only after verifying the mailbox details. Never include real secrets in a ZIP, repository, or screenshot.

## 4. Database migration and admin
1. Back up the production database before any change.
2. Run `npm run db:migrate` once against the intended database. Migration `002_blog_posts.sql` creates the blog table additively and does not remove existing records.
3. If no admin exists, create the first admin using the documented `npm run admin:create` flow from `ADMIN-USER-GUIDE.md`. If an admin already exists, do not recreate or reset it without explicit authorization.
4. Sign in at `/admin/login`. Use `/admin/blog` to create, edit, draft and publish articles.
5. Test the enquiry form and SMTP using **Settings → Send test email**.

## 5. Blog & SEO checks
- Confirm `/blog`, a published `/blog/[slug]`, category and tag pages render.
- Verify canonical URL, title, description, Open Graph metadata and Article JSON-LD on article pages.
- Check `/sitemap.xml` includes published posts, categories and tags, and `/robots.txt` points to the sitemap.
- Submit the sitemap in Google Search Console after launch.
- Blog content is plain text with blank lines between paragraphs; HTML is not executed. Verify facts and link to current official sources before publishing time-sensitive visa guidance.

## 6. Media and design checks
This source includes `public/media/roopo-hero.mp4`, `public/media/roopo-hero-poster.jpg`, all three service-card GIFs, and their WebP fallbacks. Confirm the hero and card motion visually against the locked v1.2.3 screenshot after a successful production build. Do not copy Mac `node_modules` or `.next` build output into a Linux deployment.

## 7. Current build limitation
The current assistant execution environment could not complete `npm ci` because npm registry requests failed with `EAI_AGAIN` DNS errors. This is an environment/network limitation, not a successful build. The GitHub Actions workflow is configured to run the complete checks and create the cPanel ZIP only after they pass.

## 8. Rollback
Keep the previous app release and a database backup. Roll back by restoring the previous application package/root and restarting the app. Database migrations in this release are additive; use the pre-deploy DB backup if a database rollback is necessary.
