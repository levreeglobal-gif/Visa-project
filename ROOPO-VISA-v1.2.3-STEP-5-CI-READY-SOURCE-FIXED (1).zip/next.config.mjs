/** Roopo Visa Next.js configuration. Requires a Node.js server (API routes, server actions, DB). Not compatible with static export. */
const securityHeaders = [
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
  { key: 'Strict-Transport-Security', value: 'max-age=31536000; includeSubDomains' },
];
const nextConfig = {
  images: { formats: ['image/avif', 'image/webp'], deviceSizes: [640, 750, 828, 1080, 1200, 1920], minimumCacheTTL: 60 * 60 * 24 * 30 },
  compress: true,
  poweredByHeader: false,
  reactStrictMode: true,
  serverExternalPackages: ['mysql2', 'nodemailer'],
  async headers() { return [{ source: '/:path*', headers: securityHeaders }]; },
};
export default nextConfig;
