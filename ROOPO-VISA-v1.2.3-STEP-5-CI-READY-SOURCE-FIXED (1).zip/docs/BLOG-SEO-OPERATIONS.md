# Blog & SEO operations — Roopo Visa v1.2.3

## What is included
- Public `/blog` listing and `/blog/[slug]` article pages.
- Admin `/admin/blog` for drafts, editing, publishing and deleting posts.
- Per-article SEO title, meta description, Open Graph image, canonical URL, author and Article JSON-LD.
- Published articles are included in `sitemap.xml`; drafts are excluded.
- Article body is plain text with blank lines between paragraphs. User HTML is not executed or rendered.
- Blog pages use responsive site layout and the standard site footer.

## First-time setup
1. Back up the production database before deploying code.
2. Deploy the merged source through the verified Linux build process.
3. Run `npm run db:migrate` once against the intended database. The migration runner applies `002_blog_posts.sql` once; it does not alter existing posts or content tables.
4. Sign in to `/admin`, open **Blog & SEO**, create an article as a draft, preview after publishing, and check its title/description/canonical in the rendered page source.
5. Open `/sitemap.xml` and verify published article URLs are present. Submit the sitemap in Google Search Console.

## Editorial safeguards
Publish only checked, current guidance. Do not promise visa approval, imply government affiliation, or state that a requirement is universal unless confirmed against the relevant authority. Add review dates for time-sensitive policy content and link readers to official sources.

## Verification boundary
The merged source has not been certified by a successful Linux production build or live database run in this packaging environment. The migration, build, and live checks must pass before the package is treated as deployment-ready.
