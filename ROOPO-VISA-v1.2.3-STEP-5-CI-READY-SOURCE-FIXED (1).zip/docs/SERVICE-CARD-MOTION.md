# Priority service card motion assets

The three homepage priority service cards now use a lightweight animated GIF when the visitor has not requested reduced motion, with a WebP still-image fallback.

- IVAC: `public/media/service-ivac.gif` + `service-ivac.webp`
- VFS Global: `public/media/service-vfs.gif` + `service-vfs.webp`
- Korean visa: `public/media/service-korea.gif` + `service-korea.webp`

The GIFs use a restrained, looping Ken Burns-style movement rather than fast cuts or flashing. Each GIF is roughly 0.38–0.46 MB; all three together are about 1.2 MB. Browsers with `prefers-reduced-motion: reduce` receive the static WebP fallback. The existing card hover zoom is also disabled for reduced-motion users.

The images are illustrative visual assets, not evidence of visa approval or official affiliation. Review final crops against the approved brand reference during browser QA.
