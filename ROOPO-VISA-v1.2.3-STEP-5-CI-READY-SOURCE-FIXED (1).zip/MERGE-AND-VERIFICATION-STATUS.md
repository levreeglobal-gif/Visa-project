# Roopo Visa v1.2.3 — Merge and verification status

The source combines the Next.js application from `next (2).zip` with the approved v1.2.3 replacement files. Step 3 adds animated service-card media, static reduced-motion fallbacks, and a homepage latest-blog preview.

## Current static checks
- Static preflight: 0 failures, 1 warning.
- Required public routes and priority service labels are present.
- Legacy Indian medical URL redirects to the IVAC guidance anchor.
- GIF/WebP pairs exist for all three priority service cards.
- Homepage includes a latest-blog preview that uses published posts and an empty state when none exist.
- Reduced-motion preference selects static WebP imagery.

## Production verification is incomplete
Dependency installation (`npm ci`) did not complete in the available environment. Lint, typecheck, unit tests, production build, browser testing, SMTP delivery, database operations, and live hosting remain unverified. The locked hero video/poster assets are also missing from the supplied source archives.

Do not treat this source ZIP as a verified cPanel deployment artifact. Run the included GitHub Actions workflow in a network-enabled GitHub environment and resolve all failures before deploying.
