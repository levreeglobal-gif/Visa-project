# Roopo Visa v1.2.3

Next.js + MySQL website with a secure admin panel. See DEPLOYMENT-GUIDE.md, ADMIN-USER-GUIDE.md and FINAL-AUDIT-REPORT.md (status: implemented, not build-verified).

A multi-page Roopo Visa website built on the supplied Portfolio Next.js source as the primary base, with selected low-resource patterns from the AETHER Phase 1 resource checkpoint.

**Working version:** v1.2.3 Step 5 CI-ready source (not production-build verified).

**Brand:** Roopo Visa  
**Tagline:** Support with clarity. Process with care.  
**Intended URL:** https://visa.roopo.org/  
**Source repositories:** [Portfolio](https://github.com/aitezazdev/Portfolio) (primary), [AETHER](https://github.com/giuucmp/aether-boilerplate) (selected resource patterns only).

## Pages

- Home
- About
- VFS Global Appointment Services
- GVCW Appointment Support
- IVAC Appointment Services
- Korean Visa Processing — Tourist, Student (Scholarship), Business
- Visa Processing Services
- Indian Medical Visa guidance (inside IVAC page; legacy URL redirects)
- FAQ
- Contact
- Privacy Policy
- Terms of Use

## Technology and performance

- Next.js App Router and React.
- CSS-first responsive design; no Three.js scenes, custom cursor, full-screen preloader, page-transition machinery or Lenis dependency is required by the new page experience.
- Reduced-motion preference is respected.
- No analytics is enabled by default.
- Contact form uses the server route and Nodemailer SMTP. It requires valid SMTP settings and a verified recipient before email delivery works.
- No public email address is hardcoded because one has not been confirmed.

## Local setup

1. Install Node.js compatible with the installed Next.js version.
2. Extract this ZIP and enter the `roopo-visa-website` folder.
3. Run `npm install` in a network-enabled environment.
4. Copy `.env.example` to `.env.local` and fill in the real SMTP settings only after verifying them. Do not commit secrets.
5. Run `npm run dev` and open `http://localhost:3000`.

## Production checks

Run `npm run preflight:static`, `npm run lint`, `npm run typecheck`, and `npm run build`. Then test every route at desktop and mobile widths, check reduced-motion behavior, and submit a contact form using real SMTP credentials. Do not describe the form as working until a real delivery has been confirmed.

## Hosting

The contact API uses a Node.js server route. Confirm that the target host can run the exact Next.js production server and API routes before deployment. A static export will not support this contact API as implemented.

## Content and compliance

Roopo Visa is presented as an independent visa application support service, not an embassy or government office. Appointment availability, visa eligibility and decisions remain with the relevant providers and authorities. The Privacy Policy and Terms of Use are launch drafts and should be reviewed against the actual operating entity, data practices and applicable law.

## License

The source project includes its original MIT license. Retain the required copyright and license notice when redistributing derivative source.


## v1.2.3 locked homepage information architecture
- Indian Medical Visa Processing is a dedicated homepage body sub-hero; detailed guidance appears inside IVAC Appointment Services.
- South Korean Student Bank Loan Cooperation is a second dedicated homepage body sub-hero, without claims of guaranteed financing or approval.
- The legacy `/indian-medical-travel-support` URL redirects to the IVAC guidance anchor; it is not an independent service page.
- Existing priority service pillars remain IVAC, VFS Global, and Korean Visa Processing.


## v1.2.3 merge additions

- Locked homepage replacement files integrated.
- Blog and SEO admin module at `/admin/blog`; public listing `/blog`, individual articles `/blog/[slug]`, categories `/blog/category/[category]`, and tags `/blog/tag/[tag]`.
- Apply additive migration `002_blog_posts.sql` using `npm run db:migrate` after database backup.
- Read `docs/BLOG-SEO-OPERATIONS.md` and `MERGE-AND-VERIFICATION-STATUS.md` before deployment.

## Step 5 Linux verification

`.github/workflows/linux-production-build.yml` runs dependency installation, static preflight, lint, type checking, unit/security tests, the Linux production build, and production route smoke tests. It creates a cPanel deployment artifact only if all checks pass. This package itself is source, not the final deployment ZIP.
