# Roopo Visa v1.2.3 — Step 4 Release Candidate Report

## Work completed
- Restored `public/media/roopo-hero.mp4` and `public/media/roopo-hero-poster.jpg` from the earlier Roopo Visa v1.2.3 final-source archive. These are the original project assets, not newly generated substitutes.
- Verified hero video metadata: H.264 MP4, 1280x720, 6 seconds, approximately 434 KB.
- Preserved the three animated service-card GIFs and their WebP fallbacks.
- Kept the locked public routes, blog routes, metadata, admin, database, and enquiry source intact.
- Re-ran static preflight after restoring media assets: 0 failures, 1 warning.
- Checked ZIP source integrity and generated SHA-256 for this source package.

## Build verification blocker
A full dependency installation was attempted with `npm ci`, but npm registry requests repeatedly failed with `EAI_AGAIN` for `registry.npmjs.org`. Offline installation also cannot complete because required packages are not cached. Therefore lint, TypeScript, unit tests, and `next build` could not be run honestly in this environment.

## Status
This is a **release-candidate source package**, not a production-verified or cPanel deployment ZIP. Do not overwrite the live website until GitHub Actions or another Linux environment successfully passes dependency installation, static preflight, lint, typecheck, tests, and production build, and runtime checks confirm database, admin login, blog publishing, enquiry persistence, and email behavior.

## Remaining manual/runtime checks
- Run `.github/workflows/linux-production-build.yml` on GitHub with working npm registry access.
- Inspect each public route at desktop and mobile widths.
- Verify GIF animation and reduced-motion fallback.
- Verify database migration against a backup/staging database first.
- Test admin authentication, blog draft/publish/edit/delete, enquiry persistence, and SMTP delivery.
- Confirm production environment variables in cPanel without committing secrets.
- Owner/legal review of Privacy Policy and Terms of Use drafts.
